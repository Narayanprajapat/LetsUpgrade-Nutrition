import React, { Component } from 'react';

class Food extends Component {
	constructor(props) {
		super(props);
		this.state = {
			foods: [],
			searchFood: [],
			currentFood: {
				name: '-',
				calories: 0,
				protein: 0,
				carbs: 0,
				fats: 0,
				fibre: 0,
				weight: 100,
			},
		};
	}

	// * Select Food
	selectFood(food) {
		// console.log(food);
		this.setState({ currentFood: food });
	}

	// *Calculate Weight
	calculateFood(weight) {
		let current = this.state.currentFood;
		if (weight !== '' && weight !== 0) {
			current.calories = Number(current.calories * weight) / Number(current.weight);
			current.carbs = Number(current.carbs * weight) / Number(current.weight);
			current.protein = Number(current.protein * weight) / Number(current.weight);
			current.fats = Number(current.fats * weight) / Number(current.weight);
			current.fibre = Number(current.fibre * weight) / Number(current.weight);
			current.weight = weight;
			this.setState({ currentFood: current });
		}
	}

	// * Search Function
	searchfood(value) {
		console.log(value);
		if (value.length !== 0) {
			var search = this.state.foods.filter((ele) => {
				return ele.name.toLowerCase().includes(value);
			});
			if (search.length !== 0) {
				this.setState({ searchFood: search });
			} else {
				search = [{ name: 'Not Found' }];
				this.setState({ searchFood: search });
			}
			console.log(search);
		} else {
			this.setState({ searchFood: [] });
			this.setState({ currentFood: { name: '-', calories: 0, protein: 0, carbs: 0, fats: 0, fibre: 0, weight: 0 } });
		}
	}

	// * Inbuilt Function In React.Js
	componentDidMount() {
		console.log('Component Did Mount');
		fetch('http://localhost:8080/foods')
			.then((res) => res.json())
			.then((foodData) => {
				console.log(foodData);
				this.setState({ foods: foodData });
			})
			.catch((err) => console.log(err));
	}

	// * Render Funcion
	render() {
		return (
			<div className='container'>
				<h1 style={{ textAlign: 'center', marginTop: '20px' }}>Nutrition Project</h1>
				<div className='form-group' style={{ marginTop: '30px' }}>
					<input
						className='form-control'
						placeholder='Search Food'
						onChange={(event) => {
							this.searchfood(event.target.value);
						}}
					/>
				</div>
				<div className='search-result'>
					{this.state.searchFood.map((food) => (
						<div
							className='result'
							onClick={() => {
								this.selectFood(food);
							}}
						>
							{food.name}
						</div>
					))}
				</div>
				<div className='product-display'>
					<table className='table'>
						<thead>
							<tr>
								<th>Name</th>
								<th>Calories</th>
								<th>Protein</th>
								<th>Carbs</th>
								<th>Fats</th>
								<th>Fibre</th>
								<th>Weight</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>{this.state.currentFood.name}</td>
								<td>{this.state.currentFood.calories.toFixed(2)}</td>
								<td>{this.state.currentFood.protein.toFixed(2)}</td>
								<td>{this.state.currentFood.carbs.toFixed(2)}</td>
								<td>{this.state.currentFood.fats.toFixed(2)}</td>
								<td>{this.state.currentFood.fibre.toFixed(2)}</td>
								<td>
									<input type='number' defaultValue={this.state.currentFood.weight} onChange={(event) => this.calculateFood(Number(event.target.value))} />
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		);
	}
}
export default Food;
