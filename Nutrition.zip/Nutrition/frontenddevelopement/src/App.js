import './App.css';
import Food from './Food';
function App() {
	console.log(Food);
	return (
		<div className='App'>
			<Food />
		</div>
	);
}

export default App;
